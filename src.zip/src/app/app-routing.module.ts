import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SignInComponent } from './components/sign-in/sign-in.component';
import { RegisterComponent } from './components/register/register.component';
import { FollowersComponent } from './components/followers/followers.component';
import { AccountDetailsComponent } from './components/account-details/account-details.component';
import { BlockedAccountComponent } from './components/blocked-account/blocked-account.component';
import { NewsFeedComponent } from './components/news-feed/news-feed.component';
import { SearchComponent } from './components/search/search.component';
import { UploadMediaMultipleComponent } from './components/upload-media-multiple/upload-media-multiple.component';
import { UploadSingleMediaComponent } from './components/upload-single-media/upload-single-media.component';
import { MyMediaPageComponent } from './components/my-media-page/my-media-page.component';


const routes: Routes = [
  { path: 'signin', component: SignInComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'followers', component: FollowersComponent },
  { path: 'account-details', component: AccountDetailsComponent },
  { path: 'blocked-account', component: BlockedAccountComponent },
  { path: 'newsfeed', component: NewsFeedComponent },
  { path: 'search', component: SearchComponent },
  { path: 'upload-media-multiple', component: UploadMediaMultipleComponent },
  { path: 'upload-single-media', component: UploadSingleMediaComponent },
  { path: 'my-media-page', component: MyMediaPageComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
