import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-media-page',
  templateUrl: './my-media-page.component.html',
  styleUrls: ['./my-media-page.component.css']
})
export class MyMediaPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
