import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css']
})
export class SignInComponent implements OnInit {

  rForm: FormGroup;
  username: string;
  password: string;
  constructor(private fb: FormBuilder) {
    this.onFormSubmit();
   }

  ngOnInit() {
  }

  onFormSubmit(){
    this.rForm=this.fb.group({
      'username': [this.username, Validators.required],
      'password': [this.password, Validators.required]
    })
  }

}
