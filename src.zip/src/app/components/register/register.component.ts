import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  rForm: FormGroup;
  username: string;
  password: string;
  rpassword: string;
  email: string;
  constructor(private fb: FormBuilder) {
    this.onFormSubmit();
   }

  ngOnInit() {
  }

  onFormSubmit(){
    this.rForm=this.fb.group({
      'username': [this.username, Validators.required],
      'password': [this.password, Validators.compose([Validators.required, Validators.minLength(5)])],
      'rpassword': [this.rpassword, Validators.compose([Validators.required])],
      'email': [this.email, Validators.email]
    },
    {validator: this.passwordMatchValidator}
    )
  }

  passwordMatchValidator(frm: FormGroup) {
    return frm.controls['password'].value === frm.controls['rpassword'].value ? null : {'mismatch': true};
  }

}
