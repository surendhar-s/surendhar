import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './components/app.component';
import { HeaderComponent } from './components/shared/header/header.component';
import { SignInComponent } from './components/sign-in/sign-in.component';
import { RegisterComponent } from './components/register/register.component';
import { FollowersComponent } from './components/followers/followers.component';
import { AccountDetailsComponent } from './components/account-details/account-details.component';
import { BlockedAccountComponent } from './components/blocked-account/blocked-account.component';
import { NewsFeedComponent } from './components/news-feed/news-feed.component';
import { SearchComponent } from './components/search/search.component';
import { UploadMediaMultipleComponent } from './components/upload-media-multiple/upload-media-multiple.component';
import { UploadSingleMediaComponent } from './components/upload-single-media/upload-single-media.component';
import { MyMediaPageComponent } from './components/my-media-page/my-media-page.component';
import { UserInfoComponent } from './components/user-info/user-info.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SignInComponent,
    RegisterComponent,
    FollowersComponent,
    AccountDetailsComponent,
    BlockedAccountComponent,
    NewsFeedComponent,
    SearchComponent,
    UploadMediaMultipleComponent,
    UploadSingleMediaComponent,
    MyMediaPageComponent,
    UserInfoComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
